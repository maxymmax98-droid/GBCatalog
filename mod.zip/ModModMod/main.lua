local triggered = false
local timer = 0
local showImage = false
local audioPlayed = false
local finished = false 
local Safe = 2

local spamTimer = 0
local lastSpamTime = 0
local lastSpawnTime = 0

local clip = nil
local texture = nil
local rect = nil
local shakeAmount = 30 

function Start()
    clip = Importer:ImportAudioClip("Скр.mp3")
    texture = Importer:ImportTexture("Scr.png")

    local screenRect = Input:GetScreenRect()
    local width, height = 2900, 1600
    rect = Vector4:New(screenRect.x / 2 - width / 2, screenRect.y / 2 - height / 2, width, height)
end

function toggleSafeMode()
    if Safe == 2 then
        Safe = 1
        showImage = false
        GameObject:ClearObjects()
        Main:ShowSubtitles("<color=#90d39f><u>Safe mode</u> is on", Vector3:New(0,1,0), 5)
    else
        Safe = 2
        Main:ShowSubtitles("<color=#cf6a6a><u>Safe mode</u> is off", Vector3:New(0,1,0), 3)
    end
end

function OnChatMessage(message, sender)
    if message == "?test" and not triggered then
        triggered = true
        timer = 0
        finished = false
        Safe = 2 
        Main:SendChatMessageLocal("<color=green>Process started...")
        Main:SendChatMessageLocal("<color=yellow>System: To toggle <u>Safe Mode</u> press 'I' or type '?s'</color>")
    end

    if (message == "?s" or message == "?S") then
        toggleSafeMode()
    end
end

function Update()
    if Input:GetKeyDown("I") then
        toggleSafeMode()
    end

    if not triggered or Safe == 1 then return end

    timer = timer + Time.DeltaTime

    if timer >= 10 and not audioPlayed then
        local audioObj = GameObject:Create("SCR_AUDIO")
        local src = audioObj:AddComponent("AudioSource")
        src:SetField("clip", clip)
        src:SetField("volume", 6.0)
        src:CallMethod("Play")
        audioPlayed = true
    end

    if timer >= 11.1 and timer < 15.7 then
        showImage = true
    end

    if timer >= 15.7 and not finished then
        showImage = false
        finished = true
        GameObject:ClearObjects()
        Main:SendChatMessageError("<size=40>FATAL ERROR: Script process terminated.")
        spamTimer = timer 
    end

    if finished and timer >= (spamTimer + 2.0) then
        if timer - lastSpamTime >= 0.1 then
            Main:SendChatMessageError("DELETING DATA...")
            lastSpamTime = timer
        end

        if timer - lastSpawnTime >= 0.01 then
            for i = 1, 400 do
                local obj = GameObject:Instantiate("SpawnAbles/Static/Fence Wire 3")
                if obj and obj.Transform then
                    obj.Transform.Position = Vector3:New(0, 0, 0)
                end
            end
            lastSpawnTime = timer
        end

        if timer >= (spamTimer + 12.0) then
            showImage = true
        end
    end
end

function OnGUI()
    if not showImage or texture == nil or Safe == 1 then return end

    local shakeX = (math.random() - 0.5) * 2 * shakeAmount
    local shakeY = (math.random() - 0.5) * 2 * shakeAmount

    GUI:DrawTexture(
        Vector4:New(rect.x + shakeX, rect.y + shakeY, rect.z, rect.w),
        texture,
        0, 
        true,
        1
    )
end